package smu.ai.greenmate;

import com.google.gson.annotations.SerializedName;

public class OpenAIRequest {
    @SerializedName("prompt")
    private String prompt;

    @SerializedName("max_tokens")
    private int maxTokens;

    public OpenAIRequest(String prompt, int maxTokens) {
        this.prompt = prompt;
        this.maxTokens = maxTokens;
    }

    // getters and setters
}

