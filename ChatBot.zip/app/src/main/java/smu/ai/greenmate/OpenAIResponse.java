package smu.ai.greenmate;

import com.google.gson.annotations.SerializedName;
import java.util.List;

public class OpenAIResponse {
    @SerializedName("choices")
    private List<Choice> choices;

    public List<Choice> getChoices() {
        return choices;
    }

    public static class Choice {
        @SerializedName("text")
        private String text;

        public String getText() {
            return text;
        }
    }
}

