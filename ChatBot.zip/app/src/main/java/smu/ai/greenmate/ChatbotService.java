package smu.ai.greenmate;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ChatbotService {
    private static final String BASE_URL = "https://api.openai.com/";
    private OpenAIApi api;

    public ChatbotService() {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        api = retrofit.create(OpenAIApi.class);
    }

    public void getCompletion(String prompt, Callback<OpenAIResponse> callback) {
        OpenAIRequest request = new OpenAIRequest(prompt, 100);
        Call<OpenAIResponse> call = api.getCompletion(request);
        call.enqueue(callback);
    }
}

