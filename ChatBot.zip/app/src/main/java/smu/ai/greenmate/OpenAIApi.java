package smu.ai.greenmate;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Headers;
import retrofit2.http.POST;

public interface OpenAIApi {
    @Headers({
            "Content-Type: application/json",
            "Authorization: Bearer sk-proj-0FYrtn8W5FdhhFlf9H2XT3BlbkFJijXF53374aAk9XGZW9LV" // 여기에 자신의 API 키를 입력하세요
    })
    @POST("v1/engines/davinci-codex/completions")
    Call<OpenAIResponse> getCompletion(@Body OpenAIRequest request);
}

